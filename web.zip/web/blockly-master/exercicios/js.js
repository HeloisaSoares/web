'use strict';
var workspace = null;
var fakeDragStack = [];

function start() {
  setBackgroundColor();

  // Parse the URL arguments.
  var match = location.search.match(/dir=([^&]+)/);
  var rtl = match && match[1] == 'rtl';
  document.forms.options.elements.dir.selectedIndex = Number(rtl);
  var toolbox = getToolboxElement();
  document.forms.options.elements.toolbox.selectedIndex =
      Number(toolbox.getElementsByTagName('category').length == 0);
  match = location.search.match(/side=([^&]+)/);
  var side = match ? match[1] : 'start';
  document.forms.options.elements.side.value = side;
  // Create main workspace.
  workspace = Blockly.inject('blocklyDiv',
          {comments: true,
           collapse: true,
           disable: true,
           horizontalLayout: side == 'top' || side == 'bottom',
           maxBlocks: Infinity,
           media: '../media/',
           oneBasedIndex: true,
           readOnly: false,
           rtl: rtl,
           scrollbars: true,
           toolbox: toolbox,
           toolboxPosition: side == 'top' || side == 'start' ? 'start' : 'end',

          });
  // Restore previously displayed text.
  if (sessionStorage) {
    var text = sessionStorage.getItem('textarea');
    if (text) {
      document.getElementById('importExport').value = text;
    }
    // Restore event logging state.
    var state = sessionStorage.getItem('logEvents');
    logEvents(Boolean(Number(state)));
  } else {
    // MSIE 11 does not support sessionStorage on file:// URLs.
    logEvents(false);
  }
  taChange();
}
workspace.addChangeListener(myUpdateFunction);


    function setBackgroundColor() {
  var lilac = '#d6d6ff';

  var currentPage = window.location.href;
  var regexFile = /^file[\S]*$/;

  if (regexFile.test(currentPage)) {
    document.getElementsByTagName('body')[0].style.backgroundColor = lilac;
  }
}

function getToolboxElement() {
  var match = location.search.match(/toolbox=([^&]+)/);
  return document.getElementById('toolbox-' + (match ? match[1] : 'categories'));
}

function toXml() {
  var output = document.getElementById('importExport');
  var xml = Blockly.Xml.workspaceToDom(workspace);
  output.value = Blockly.Xml.domToPrettyText(xml);
  output.focus();
  output.select();
  taChange();
}

function fromXml() {
  var input = document.getElementById('importExport');
  var xml = Blockly.Xml.textToDom(input.value);
  Blockly.Xml.domToWorkspace(xml, workspace);
  taChange();
}

function toCode(lang) {
  var output = document.getElementById('importExport');
  output.value = Blockly[lang].workspaceToCode(workspace);
  taChange();
}
function run() {
        Blockly.JavaScript.addReservedWords('code');
        var code= Blockly.JavaScript.workspaceToCode(workspace);
 try{
     eval(code);
 }catch(e){
     alert(e);
 }
}

function taChange() {
  var textarea = document.getElementById('importExport');
  if (sessionStorage) {
    sessionStorage.setItem('textarea', textarea.value);
  }
  var valid = true;
  try {
    Blockly.Xml.textToDom(textarea.value);
  } catch (e) {
    valid = false;
  }
  document.getElementById('import').disabled = !valid;
}

function logEvents(state) {
  var checkbox = document.getElementById('logCheck');
  checkbox.checked = state;
  if (sessionStorage) {
    sessionStorage.setItem('logEvents', Number(state));
  }
  if (state) {
    workspace.addChangeListener(logger);
  } else {
    workspace.removeChangeListener(logger);
  }
}

function logger(e) {
  console.log(e);
}